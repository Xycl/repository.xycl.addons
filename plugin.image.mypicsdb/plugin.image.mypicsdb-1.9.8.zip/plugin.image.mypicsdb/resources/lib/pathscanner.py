#!/usr/bin/python
# -*- coding: utf8 -*-

""" 
Copyright (C) 2012 Xycl

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.

"""

import os, urllib, re
import xbmc, xbmcvfs
import CharsetDecoder as decoder

class Scanner(object):

    def walk(self, path, recursive = False, types = None):
        filenames = []
        dirnames  = []

        if type(path).__name__=='unicode':
            path = path.encode('utf-8')
            
        if path.startswith('multipath://'):
            dirs = path[12:-1].split('/')
            for item in dirs:
                dirnames1, filenames1 = self._walk(urllib.unquote_plus(item), recursive, types)

                for dirname in dirnames1:
                    dirnames.append(dirname)
                for filename in filenames1:
                    filenames.append(filename)               
               
        else:
            dirnames, filenames = self._walk(path, recursive, types)

                    
        return dirnames, filenames


    def _walk(self, path, recursive, types):
        filenames = []
        dirnames   = []
        files     = []

        path = xbmc.translatePath(path)

        if xbmcvfs.exists(xbmc.translatePath(path)) or re.match(r"[a-zA-Z]:\\", path) is not None:
            subdirs, files = xbmcvfs.listdir(path)
            for subdir in subdirs:
                dirnames.append(os.path.join(path, subdir))

            for filename in files:
                if types is not None:
                    if os.path.splitext(filename)[1].upper() in types or os.path.splitext(filename)[1].lower() in types :
                        filenames.append(os.path.join(path, filename))
                else:              
                    filenames.append(os.path.join(path, filename))


            if recursive:
                for item in subdirs:
                    dirnames1, filenames1 = self._walk(os.path.join(path, item), recursive, types)
                    for item in dirnames1:
                        dirnames.append(item)
                    for item in filenames1:
                        filenames.append(item)
        
        return dirnames, filenames


    def getname(self, filename):
        filename = decoder.smart_unicode(filename)
        return os.path.basename(filename)

    def delete(self, filename):
        xbmcvfs.delete(filename)
        
    def getlocalfile(self, filename):
        
        filename = decoder.smart_unicode(filename)
        
        # Windows NEEDS unicode but OpenElec utf-8
        try:
            exists = os.path.exists(filename)
        except:
            exists = os.path.exists(decoder.smart_utf8(filename))
        if exists:
            return filename, False
        else:
            tempdir     = xbmc.translatePath('special://temp')
            basefilename    = self.getname(filename)
            destination = os.path.join(tempdir, basefilename)
            xbmcvfs.copy(filename, destination)

            return decoder.smart_unicode(destination), True

        